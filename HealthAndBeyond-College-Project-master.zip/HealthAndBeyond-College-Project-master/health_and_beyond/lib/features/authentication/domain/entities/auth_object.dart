class AuthObject {
  final String type, email, password;

  AuthObject({
    required this.type,
    required this.email,
    required this.password,
  });
}
