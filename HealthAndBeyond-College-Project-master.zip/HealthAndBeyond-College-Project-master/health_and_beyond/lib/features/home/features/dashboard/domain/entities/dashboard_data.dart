class DashboardData {
  final String data;

  DashboardData({required this.data});
}
