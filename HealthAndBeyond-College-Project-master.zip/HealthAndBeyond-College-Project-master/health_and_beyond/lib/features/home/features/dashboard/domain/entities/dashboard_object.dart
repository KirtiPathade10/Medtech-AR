class DashboardObject {
  final String type, uid, city, state;

  DashboardObject({
    required this.type,
    required this.uid,
    required this.city,
    required this.state,
  });
}
