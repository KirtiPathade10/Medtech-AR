class ProfileResponse {
  final String data;

  ProfileResponse({required this.data});
}
