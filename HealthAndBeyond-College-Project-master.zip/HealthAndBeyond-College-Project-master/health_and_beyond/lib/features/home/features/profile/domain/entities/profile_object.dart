class ProfileObject {
  final String uid, type;

  ProfileObject({required this.uid, required this.type});
}
