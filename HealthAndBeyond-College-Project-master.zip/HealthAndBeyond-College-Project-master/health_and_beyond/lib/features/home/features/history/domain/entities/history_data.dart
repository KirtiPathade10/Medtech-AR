class HistoryData {
  final String data;

  HistoryData({required this.data});
}
