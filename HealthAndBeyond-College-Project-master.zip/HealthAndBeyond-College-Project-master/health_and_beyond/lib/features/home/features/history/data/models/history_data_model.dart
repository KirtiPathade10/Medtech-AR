import 'package:health_and_beyond/features/home/features/history/domain/entities/history_data.dart';

class HistoryDataModel extends HistoryData {
  final String data;

  HistoryDataModel({required this.data}) : super(data: data);
}
