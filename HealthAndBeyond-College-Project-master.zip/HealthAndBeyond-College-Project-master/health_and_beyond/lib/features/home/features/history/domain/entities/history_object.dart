class HistoryObject {
  final String uid, type;

  HistoryObject({required this.uid, required this.type});
}
