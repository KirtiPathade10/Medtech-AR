class Patient {
  final String firstName, dob, city, state;

  Patient({
    required this.firstName,
    required this.dob,
    required this.city,
    required this.state,
  });
}
