class PatientData {
  final String data;

  PatientData({required this.data});
}
