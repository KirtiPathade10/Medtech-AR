class PatientObject {
  final String uid, type;

  PatientObject({required this.uid, required this.type});
}
