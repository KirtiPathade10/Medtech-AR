class Disease {
  final String name;

  Disease({required this.name});
}
