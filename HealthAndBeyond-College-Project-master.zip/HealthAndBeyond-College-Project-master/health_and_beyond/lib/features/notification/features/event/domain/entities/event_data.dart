class EventData {
  final String data;

  EventData({required this.data});
}
