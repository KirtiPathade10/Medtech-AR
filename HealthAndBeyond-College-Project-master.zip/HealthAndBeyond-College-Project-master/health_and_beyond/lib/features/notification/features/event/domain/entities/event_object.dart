class EventObject {
  final String type, id;

  EventObject({required this.type, required this.id});
}
