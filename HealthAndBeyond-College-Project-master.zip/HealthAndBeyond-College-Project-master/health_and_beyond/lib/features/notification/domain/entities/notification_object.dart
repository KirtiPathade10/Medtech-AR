class NotificationObject {
  final String type, uid, city, state;

  NotificationObject({
    required this.type,
    required this.uid,
    required this.city,
    required this.state,
  });
}
