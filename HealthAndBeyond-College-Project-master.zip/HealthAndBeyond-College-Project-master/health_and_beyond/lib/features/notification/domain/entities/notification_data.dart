class NotificationData {
  final String data;

  NotificationData({required this.data});
}
