class NetworkException implements Exception {}

class CacheException implements Exception {}
