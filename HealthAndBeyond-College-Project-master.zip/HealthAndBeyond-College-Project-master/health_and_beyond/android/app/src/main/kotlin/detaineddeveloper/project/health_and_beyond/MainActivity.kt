package detaineddeveloper.project.health_and_beyond

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
